clc;clear all;close all;
%% Defining the system
A=[-27 3.6 6;9.6 -12.5 0;0 9 -5];%%Characteristics of the Time-Delay system
Ad=[0 0 0;21 0 0;0 0 0];
B=[0.26 0;-0.9 -0.8;0 0.18];
C=[0 1 0];
D=0;

k=[-0.0004 -3.3044 -0.0006;0.0020 45.9131 84.0699];%%controller gain


L=[6.4650 9.5660 16.0991]';%%observer gain


t=0:0.1:10;

delay=struct('delay',0.06,'a',Ad,'b',0,'c',0,'d',0);%internal delay of 0.06s

sys1=delayss(A,B,C,D,delay);%%uncontrolled
An=sys1.A+B*k;
Ao=sys1.A-L*C;
sys2=delayss(An,B,C,D,delay);%%controlled
sys3=delayss(Ao,B,C,D,delay);%%with observer
pzmap(sys1);
hold on
pzmap(sys2);
hold on
pzmap(sys3);
%% Getting response from the uncontrolled system


r1=0.5*ones(1,numel(t));
r2=  20* sin(0.7*t);

u=[r1;r2];%%input
x00=[3 0.25 -0.25]';%%initial
[y,x] = lsim(sys1.A,sys1.B,sys1.C,sys1.D,u,t,x00);%%simulation of uncontrolled
[y1,x1] = lsim(sys2.A,sys2.B,sys2.C,sys2.D,u,t,x00);%%simulation of controlled
[y2,x2] = lsim(sys3.A,sys3.B,sys3.C,sys3.D,u,t,x00);%%simulation of observer
%% Getting response from the uncontrolled system

figure
plot(1:numel(t),x(:,1),'color','r');
hold on
plot(1:numel(t),x(:,2),'color',[0.3010 0.7450 0.9330]);
hold on
plot(1:numel(t),x(:,3),'color','k');
legend('intake manifold pressure','exhaust pressure','compressor power','location','best')
ylabel('State Variables');
xlabel('Time(s)');
title('Unstable states of the system in the absence of the controller');
%% Getting response when control input and observer are applied
figure
subplot(2,2,1)
plot(1:numel(t),x1(:,1),'color','k');
hold on
plot(1:numel(t),x2(:,1),'color','r','LineStyle',':');
legend('state','estimated state','location','best')
ylabel('x1');
xlabel('Time(s)');
title('intake manifold pressure');
hold on

subplot(2,2,2)

plot(1:numel(t),x1(:,2),'color','k');
hold on
plot(1:numel(t),x2(:,2),'color','r','LineStyle',':');

legend('state','estimated state','location','best')
ylabel('x2');
xlabel('Time(s)');
title('exhaust pressure');

hold on


subplot(2,2,[3,4])
plot(1:numel(t),x1(:,3),'color','k');
hold on
plot(1:numel(t),-x2(:,3),'color','r','LineStyle',':');

legend('state','estimated state','location','best')
ylabel('x3');
xlabel('Time(s)');
title('compressor power');


