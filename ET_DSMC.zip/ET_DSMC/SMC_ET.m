clear;close all;clc;

% Simulation time 
T=50;
dt=0.01;
t = 0:dt:T;

% Number of agents
N = 6;

%MAS specifications

K=20;
A=[0 1 0 0 0 0;1 0 0 0 0 1;0 0 0 1 0 0;0 0 1 0 1 0;0 0 0 1 0 1;0 1 0 0 1 0];
B=[0 0 0 0 0 0;0 1 0 0 0 0;0 0 1 0 0 0;0 0 0 1 0 0;0 0 0 0 1 0;0 0 0 0 0 1];
L=[1 -1 0 0 0 0;-1 2 0 0 0 -1;0 0 1 -1 0 0;0 0 -1 2 -1 0;0 0 0 -1 2 -1;0 -1 0 0 -1 2];H=L+B;
O=[K*H,zeros(N,N);zeros(N,N),K*H-eye(N,N)];
eig_O=eig(O);
eig_z=eig(L*L+B);
nkh=norm(K*H);
G=graph(A);
A=kron(A,eye(2));
B=kron(B,eye(2));
L=kron(L,eye(2));
H=kron(H,eye(2));
O=kron(O,eye(2));
zeta=max(eig_z);

%Define initial matrices
Surf=zeros(2*N,length(t)+1);
U=zeros(2*N,length(t)+1);
Us=zeros(2*N,length(t)+1);
Ul=zeros(2*N,length(t)+1);
Ul_temp=zeros(2*N,length(t)+1);
X=zeros(2*N,length(t)+1);
Xhat=zeros(2*N,length(t)+1);
V=zeros(2*N,length(t)+1);
Vhat=zeros(2*N,length(t)+1);
k=zeros(N,1);
F=zeros(N,length(t)+1);
Q=zeros(2*N,length(t)+1);
e1=zeros(2*N,length(t)+1);
e2=zeros(2*N,length(t)+1);
E1=zeros(N,length(t)+1);
E2=zeros(N,length(t)+1);
event=zeros(1,2*N);
% Initialize agent states and leader state
X_leader = zeros(2,length(t)+1);% Initial position of the leader
Xlhat=zeros(2,length(t)+1);
V_leader=zeros(2,length(t)+1);
Vlhat=zeros(2,length(t)+1);
El1=zeros(1,length(t)+1);
El2=zeros(1,length(t)+1);
%Sliding surface constants
etha1=0.1;
etha2=0.2;
delta1=2.8;
delta2=0.001;

%event-trigger constants
alpha=0.02;
beta=0.98;
epsilon=0.001;
ro=0.0002;
phi=2;
tetha=5;

%initial values
X(:,1)=[1;-0.8; -2.4; 4.8; 1.2; 2.4; 0; -4; ...
    4; -1.2; 4.8; 2];
V(:,1)=[-0.2; -0.1; 04; 0.1; -0.2; -0.3; -0.3; -0.3; -0.4; -0.2; -0.2; 0.1];
X_leader(:,1)=[0.5;-1.2];V_leader(:,1)=[0.2 ;-0.8];

% Loop through the simulation time
for m=1:length(t)-1
       % Update Position and Velocity of the agents
      X(:,m+1)= V(:,m)*dt+X(:,m);
      V(:,m+1)=V(:,m)+(-0.1*X(:,m)-0.2*V(:,m)+U(:,m))*dt;

%Agent position and velocitiy last-triggered-value error

   e1(:,m)=Xhat(:,m)-X(:,m);
   e2(:,m)=Vhat(:,m)-V(:,m);

   E1(1,m)=sqrt(e1(1,m)^2+e1(2,m)^2);E1(2,m)=sqrt(e1(3,m)^2+e1(4,m)^2);E1(3,m)=sqrt(e1(5,m)^2+e1(6,m)^2);E1(4,m)=sqrt(e1(7,m)^2+e1(8,m)^2);
   E1(5,m)=sqrt(e1(11,m)^2+e1(10,m)^2);E1(6,m)=sqrt(e1(11,m)^2+e1(12,m)^2);
   E2(1,m)=sqrt(e1(1,m)^2+e1(2,m)^2);E2(2,m)=sqrt(e1(3,m)^2+e1(4,m)^2);E2(3,m)=sqrt(e1(5,m)^2+e1(6,m)^2);E2(4,m)=sqrt(e1(7,m)^2+e1(8,m)^2);
   E2(5,m)=sqrt(e1(11,m)^2+e1(10,m)^2);E2(6,m)=sqrt(e1(11,m)^2+e1(12,m)^2);


   % Update Position and Velocity of the leader
     X_leader(:,m+1)=V_leader(:,m)*dt+X_leader(:,m);
     V_leader(:,m+1)=((-0.1*X_leader(:,m))-0.2*V_leader(:,m))*dt+V_leader(:,m);     

     %Leader position and velocitiy last-triggered-value error
     el1(1:2,m)=[Xlhat(1,m)-X_leader(1,m);Xlhat(2,m)-X_leader(2,m)];
     El1(1,m)=sqrt(el1(1,m)^2+el1(2,m)^2);
     el2(1:2,m)=[Vlhat(1,m)-V_leader(1,m);Vlhat(2,m)-V_leader(2,m)];
     El2(1,m)=sqrt(el2(1,m)^2+el2(2,m)^2);

%ET condition

     for n=1:2*N
         if rem(n,2)==1
F(n,m)=ro*(norm(L(n,:)*X(:,m))^2+norm(L(n,:)*V(:,m))^2+B(n,n)*(norm((X_leader(1,m)-X(n,m)))^2+norm((V_leader(1,m)-V(n,m)))^2))...
    +phi*exp(-tetha*t(m)*dt);
         else
F(n,m)=ro*(norm(L(n,:)*X(:,m))^2+norm(L(n,:)*V(:,m))^2+B(n,n)*(norm((X_leader(2,m)-X(n,m)))^2+norm((V_leader(2,m)-V(n,m)))^2))...
    +phi*exp(-tetha*t(m)*dt);
         end
     if norm(e1(n,m))^2+norm(e2(n,m))^2+B(n,n)*(norm(el1(1,m))^2+norm(el2(1,m))^2) > F(n,m)
    Xhat(n,m)=X(n,m);
    Vhat(n,m)=V(n,m);
    if rem(n,2)==1
        Xlhat(1,m)=X_leader(1,m);
    Vlhat(1,m)=V_leader(1,m);
    else
Xlhat(2,m)=X_leader(2,m);
    Vlhat(2,m)=V_leader(2,m);
    end


event(n)=event(n)+1;
    % Update integral sliding mode controller


     end     

     end
    
     Q(1,m)=F(1,m)+F(2,m);Q(2,m)=F(3,m)+F(4,m);Q(3,m)=F(5,m)+F(6,m);Q(4,m)=F(7,m)+F(8,m);
     Q(5,m)=F(11,m)+F(10,m);Q(6,m)=F(11,m)+F(12,m);



 %Controller update
      
Ul(:,m)=20*(L*(Xhat(:,m)+Vhat(:,m))-B*(Xhat(:,m)-kron(Xlhat(:,m),ones(N,1))+Vhat(:,m)-kron(Vlhat(:,m),ones(N,1))));
for n=1:2*N

Us(n,m)=-(etha1*norm(Xhat(n,m))+etha2*norm(Vhat(n,m))+delta1+delta2)*sign(Surf(n,m));

end
      U(:,m)=Ul(:,m)+Us(:,m);

%Sliding mode design
   Surf(:,m)=H*(V(:,m)-kron(V_leader(:,m),ones(N,1))-V(:,1)-kron(V_leader(:,1),ones(N,1))-sum(H*Ul(:,m),2));     

 
end



% Plot the results
figure;
subplot(2,2,[1 2]);

    plot(1:(length(e1(1, :))), e1(2, :), 'LineWidth', 1.5);
hold on;
    plot(1:(length(e1(1, :))), e1(4, :), 'LineWidth', 1.5);
   plot(1:(length(e1(1, :))), e1(6, :), 'LineWidth', 1.5);
   plot(1:(length(e1(1, :))), e1(8, :), 'LineWidth', 1.5);
   plot(1:(length(e1(1, :))), e1(10, :), 'LineWidth', 1.5);
   plot(1:(length(e1(1, :))), e1(12, :), 'LineWidth', 1.5);
  plot(1:(length(el1(1, :))), el1(1, :),':');

   
   hold off
xlabel('Time');
ylabel('Position');
title('Agent Positions');
legend('x11','x12','x13','x14','x15','x16','location','best')
subplot(2,2,[3 4]);

    plot(1:(length(t)+1), Xhat(2, :), 'LineWidth', 1.5);
hold on;
    plot(1:(length(t)+1), Xhat(4, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Xhat(6, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Xhat(8, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Xhat(10, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Xhat(12, :), 'LineWidth', 1.5);
plot(1:(length(t)+1), Xlhat(2, :),':');
   
   hold off
xlabel('Time');
ylabel('Position');
title('Agent Positions');
legend('x2 1','x22','x23','x24','x25','x26','location','best')
figure;
subplot(2,2,[1 2]);

    plot(1:(length(t)+1), X(1, :), 'LineWidth', 1.5);
hold on;
    plot(1:(length(t)+1), X(3, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), X(5, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), X(7, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), X(9, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), X(11, :), 'LineWidth', 1.5);
  plot(1:(length(t)+1), X_leader(1, :),':');

   
   hold off
xlabel('Time');
ylabel('Position');
title('Agent Positions');
legend('x11','x12','x13','x14','x15','x16','location','best')
subplot(2,2,[3 4]);

    plot(1:(length(t)+1), X(2, :), 'LineWidth', 1.5);
hold on;
    plot(1:(length(t)+1), X(4, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), X(6, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), X(8, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), X(10, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), X(12, :), 'LineWidth', 1.5);
plot(1:(length(t)+1), X_leader(2, :),':');
   
   hold off
xlabel('Time');
ylabel('Position');
title('Agent Positions');
legend('x2 1','x22','x23','x24','x25','x26','location','best')

figure;
subplot(2,2,[1 2]);

    plot(1:(length(t)+1), Vhat(1, :), 'LineWidth', 1.5);
hold on;
    plot(1:(length(t)+1),Vhat(3, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Vhat(5, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Vhat(7, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Vhat(9, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Vhat(11, :), 'LineWidth', 1.5);
  plot(1:(length(t)+1), Vlhat(1, :),':');

   
   hold off
xlabel('Time');
ylabel('Velocity');
title('Agent velocities');
legend('v11','v12','v13','v14','v15','v16','location','best')
subplot(2,2,[3 4]);

    plot(1:(length(t)+1), X(2, :), 'LineWidth', 1.5);
hold on;
    plot(1:(length(t)+1),V(4, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), V(6, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), V(8, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), V(10, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), V(12, :), 'LineWidth', 1.5);
plot(1:(length(t)+1), V_leader(2, :),':');
   
   hold off
xlabel('Time');
ylabel('Velocity');
title('Agent Velocities');
legend('v21','v22','v23','v24','v25','v26','location','best')
figure;
subplot(2,2,[1 2]);
    plot(1:(length(t)+1), Surf(1, :), 'LineWidth', 1.5);
hold on;
    plot(1:(length(t)+1),Surf(3, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Surf(5, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Surf(7, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Surf(9, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Surf(11, :), 'LineWidth', 1.5);
   hold off
xlabel('Time');
ylabel('Sliding Surface');
title('Sliding Surface of Agents');
legend('s11','s12','s13','s14','s15','s16','location','best')

subplot(2,2,[3 4]);
    plot(1:(length(t)+1), Surf(1, :), 'LineWidth', 1.5);
hold on;
    plot(1:(length(t)+1),Surf(3, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Surf(5, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Surf(7, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Surf(9, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), Surf(11, :), 'LineWidth', 1.5);
   hold off
xlabel('Time');
ylabel('Sliding Surface');
title('Sliding Surface of Agents');
legend('s21','s22','s23','s24','s25','s26','location','best')
figure

    plot(1:(length(t)+1), U(1, :), 'LineWidth', 1.5);
hold on;
    plot(1:(length(t)+1),U(3, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), U(5, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), U(7, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), U(9, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), U(11, :), 'LineWidth', 1.5);

   
   hold off
xlabel('Time');
title('Control inputs');
legend('u11','u12','u13','u14','u15','u16','location','best')

figure

    plot(1:(length(t)+1), U(2, :), 'LineWidth', 1.5);
hold on;
    plot(1:(length(t)+1),U(4, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), U(6, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), U(8, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), U(10, :), 'LineWidth', 1.5);
   plot(1:(length(t)+1), U(12, :), 'LineWidth', 1.5);
   
   hold off
xlabel('Time');
title('Control inputs');
legend('u21','u22','u23','u24','u25','u26','location','best')
