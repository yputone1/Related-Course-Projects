%Novel observer design

clc; clear; close all;

[t,v] = ode45(@observer,[0 2],[0.5;-0.3;0.3;0.5;0.95;-0.45;1;1.5;-2.5;1.5]);
figure(1)
plot(t,v(:,1),'r'); hold on
plot(t,v(:,3),'g'); hold on
plot(t,v(:,5),'b'); hold on
plot(t,v(:,7),'y'); hold on
plot(t,v(:,9),'m');
title('Evoultions of the observer states \zeta_i and state of the leader x_1_0 ');
xlabel('t/s'); ylabel('\zeta_i');
legend('x_1_0','\zeta_1','\zeta_2','\zeta_3','\zeta_4')

figure(2)
plot(t,v(:,2),'r'); hold on
plot(t,v(:,4),'g'); hold on
plot(t,v(:,6),'b'); hold on
plot(t,v(:,8),'y'); hold on
plot(t,v(:,10),'m');
title('Evoultions of the observer states \eta_i and state of the leader x_2_0');
xlabel('t/s'); ylabel('\eta_i');
legend('x_1_0','\eta_1','\eta_2','\eta_3','\eta_4')

figure(3)
plot(t,v(:,3)-v(:,1),'g'); hold on
plot(t,v(:,5)-v(:,1),'b'); hold on
plot(t,v(:,7)-v(:,1),'y'); hold on
plot(t,v(:,9)-v(:,1),'r');
title('estimation error for x_1_0 ');
xlabel('t/s'); ylabel('errors');
legend('e_11','e_21','e_31','e_41')

figure(4)
plot(t,v(:,4)-v(:,2),'g'); hold on
plot(t,v(:,6)-v(:,2),'b'); hold on
plot(t,v(:,8)-v(:,2),'y'); hold on
plot(t,v(:,10)-v(:,2),'r');
title('estimation error for x_2_0');
xlabel('t/s'); ylabel('estimation errors');
legend('e_21','e_22','e_23','e_24');

function [dvdt]=observer(t,v)
eps=4;
N=4;
ghama1= eps*sqrt(N)/(2*0.395)^(1.5);
ghama2= eps*sqrt(N)/(2*0.395)^(1.5);
p1=eps*sqrt(eps/(2*0.395));
p2=1.6+eps*sqrt(eps/(2*0.395));
dvdt=zeros(10,1);
f0=-(v(1))-0.25*v(2);
dvdt(1) = v(2);
dvdt(2) = f0 ;
dvdt(3)= v(4)+p1*sign(v(5)+v(9)+v(1)-3*v(3))+...
        ghama1*sign(v(5)+v(9)+v(1)-3*v(3))*(v(5)+v(9)+v(1)-3*v(3))^2;
dvdt(4)= p2*sign(v(6)+v(10)+v(2)-3*v(4))+...
        ghama2*sign(v(6)+v(10)+v(2)-3*v(4))*(v(6)+v(10)+v(2)-3*v(4))^2;
dvdt(5)= v(6)+p1*sign(v(3)+v(7)+v(9)+v(1)-4*v(5))+...
        ghama1*sign(v(3)+v(7)+v(9)+v(1)-...
        4*v(5))*(v(3)+v(7)+v(9)+v(1)-4*v(5))^2;
dvdt(6)= p2*sign(v(4)+v(8)+v(10)+v(2)-4*v(6))+...
        ghama2*sign(v(4)+v(8)+v(10)+v(2)-...
        4*v(6))*(v(4)+v(8)+v(10)+v(2)-4*v(6))^2;
dvdt(7)= v(8)+p1*sign(v(5)-v(7))+...
        ghama1*sign(v(5)-v(7))*(v(5)-v(7))^2;
dvdt(8)= p2*sign(v(6)-v(8))+...
        ghama2*sign(v(6)-v(8))*(v(6)-v(8))^2;
dvdt(9)= v(10)+p1*sign(v(3)+v(5)-2*v(9))+...
        ghama1*sign(v(3)+v(5)-2*v(9))*(v(3)+v(5)-2*v(9))^2;
dvdt(10)= p2*sign(v(4)+v(6)-2*v(10))+...
        ghama2*sign(v(4)+v(6)-2*v(10))*(v(4)+v(6)-2*v(10))^2;
end
